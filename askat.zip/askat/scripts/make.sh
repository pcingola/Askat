#!/bin/sh

# Build
rm -vf Askat.jar
cd $HOME/workspace/Askat/
ant
cd -
