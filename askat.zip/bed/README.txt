GRCh37.69.genes.bed.gz                   # Human genes: all genes
GRCh37.69.genes.pc.ud5k.bed.gz           # Human genes: only protein coding genes, intervals expanded 5K upstream & downstream
GRCh37.69.genes.ud5k.bed.gz              # Human genes: all genes, intervals expanded 5K upstream & downstream

